"""Isolated copy of the existing MorphProto + ContextCF implementation."""
