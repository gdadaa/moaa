"""Coupled CF + MorphPrototype. Imports (never replaces) the installed singles.
Only paired, actually perturbed source instances may update prototype memory.
"""
import torch
from torch.nn import functional as F
from mmdet.registry import MODELS
from .dino_candidates_v3 import (
    DINOContextCF, DINOMorphPrototype, check_samples, boxes, domain_id,
    roi_vectors, total_loss)


@MODELS.register_module(name='Combo24ContextMorph')
class DINOContextMorphCombo(DINOMorphPrototype):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        shape = (4, self.num_feature_levels, self.embed_dims)
        self.register_buffer('context_mean', torch.zeros(shape))
        self.register_buffer('context_std', torch.ones(shape))
        self.register_buffer('context_seen', torch.zeros(4, self.num_feature_levels, dtype=torch.bool))
        self.register_buffer('paired_updates', torch.zeros((), dtype=torch.long))
        self._paired_rois = None

    def update_bank(self, d, vectors):
        # Suppress the parent's unconditional single-view updates. The two
        # transformer passes must retrieve from the SAME frozen bank snapshot.
        pass

    def pre_decoder(self, memory, memory_mask, spatial_shapes, batch_data_samples=None):
        if self.training:
            h, w = [int(x) for x in spatial_shapes[0]]
            dense = memory[:, :h*w].transpose(1, 2).reshape(memory.shape[0], memory.shape[-1], h, w)
            self._paired_rois = [roi_vectors(dense[i], sample).detach()
                                 for i, sample in enumerate(batch_data_samples)]
        return super().pre_decoder(memory, memory_mask, spatial_shapes, batch_data_samples)

    @torch.no_grad()
    def update_reliable(self, d, original, intervened):
        if original.shape != intervened.shape:
            raise RuntimeError('Paired ROIs lost instance correspondence')
        if not len(original):
            return original.new_zeros((0,)), 0
        a = F.normalize(original.float(), dim=-1)
        b = F.normalize(intervened.float(), dim=-1)
        distance = (1 - (a*b).sum(-1)).clamp(0, 2)
        tau = float(self.candidate_cfg.get('stability_temperature', .1))
        if tau <= 0:
            raise ValueError('stability_temperature must be positive')
        reliability = torch.exp(-distance / tau)
        threshold = float(self.candidate_cfg.get('update_threshold', .5))
        if not 0 <= threshold <= 1:
            raise ValueError('update_threshold must be in [0,1]')
        count = 0
        for vec, weight, v0, v1 in zip(F.normalize(a+b, dim=-1), reliability, original, intervened):
            if weight < threshold or v0.norm() < 1e-6 or v1.norm() < 1e-6:
                continue
            seen = self.morph_seen[d]
            if not seen.all():
                j = int((~seen).nonzero()[0])
                self.morph_bank[d, j].copy_(vec)
                self.morph_seen[d, j] = True
            else:
                j = int((self.morph_bank[d] @ vec).argmax())
                rate = .05 * weight
                updated = (1-rate) * self.morph_bank[d, j] + rate * vec
                self.morph_bank[d, j].copy_(F.normalize(updated, dim=0))
            count += 1
        self.paired_updates.add_(count)
        return reliability, count

    def loss(self, batch_inputs, batch_data_samples):
        samples, removed = check_samples(batch_data_samples)
        features = self.extract_feat(batch_inputs)
        cpu_rng = torch.get_rng_state()
        device = batch_inputs.device
        cuda_rng = torch.cuda.get_rng_state(device) if device.type == 'cuda' else None
        heads = self.forward_transformer(features, samples)
        original_rois = self._paired_rois
        prototype_aux = self._prototype_aux
        losses = self.bbox_head.loss(**heads, batch_data_samples=samples)
        losses['loss_morph_prototype'] = self.ramp() * self.candidate_cfg.get('prototype_weight', .1) * prototype_aux
        zero = heads['hidden_states'].sum() * 0
        losses.update(loss_context_cf=zero, loss_dn_invariance=zero, cf_active=zero.detach(),
                      pair_reliability_mean=zero.detach(), prototype_updates=zero.detach())
        altered, used = DINOContextCF.counterfactual(self, features, samples)
        probability = float(self.candidate_cfg.get('cf_probability', .25))
        # Exclude unaltered images: identical features do not prove robustness.
        changed = [any(bool((x[i].detach()-y[i].detach()).abs().max() > 1e-6)
                       for x,y in zip(features, altered)) for i in range(len(samples))]
        if used and any(changed) and (self.smoke_mode or float(torch.rand(())) < probability):
            devices = [device.index if device.index is not None else torch.cuda.current_device()] if device.type == 'cuda' else []
            with torch.random.fork_rng(devices=devices):
                torch.set_rng_state(cpu_rng)
                if cuda_rng is not None:
                    torch.cuda.set_rng_state(cuda_rng, device)
                other = self.forward_transformer(altered, samples)
            intervened_rois = self._paired_rois
            other_losses = self.bbox_head.loss(**other, batch_data_samples=samples)
            losses['loss_context_cf'] = self.ramp() * self.candidate_cfg.get('cf_weight', .25) * total_loss(other_losses)
            meta = heads.get('dn_meta') or {}
            n = int(meta.get('num_denoising_queries', 0))
            groups = int(meta.get('num_denoising_groups', 0))
            terms, reliability_values, updates = [], [], 0
            for i, sample in enumerate(samples):
                if not changed[i]:
                    continue
                count = len(boxes(sample))
                if n and groups and count:
                    ids = (torch.arange(groups, device=device)[:, None] * (n//groups)
                           + torch.arange(count, device=device)[None]).flatten()
                    a = F.normalize(heads['hidden_states'][-1, i, ids].detach().float(), dim=-1)
                    b = F.normalize(other['hidden_states'][-1, i, ids].float(), dim=-1)
                    terms.append((1 - (a*b).sum(-1)).mean())
                values, accepted = self.update_reliable(domain_id(sample), original_rois[i], intervened_rois[i])
                if values.numel():
                    reliability_values.append(values)
                updates += accepted
            if terms:
                losses['loss_dn_invariance'] = self.ramp() * self.candidate_cfg.get('consistency_weight', .1) * torch.stack(terms).mean()
            if reliability_values:
                losses['pair_reliability_mean'] = torch.cat(reliability_values).mean().detach()
            losses['prototype_updates'] = zero.detach() + updates
            losses['cf_active'] = zero.detach() + 1
        losses['prototype_count'] = self.morph_seen.float().sum().detach()
        # Release temporary references, not checkpointed state.
        self._paired_rois = None
        self._prototype_aux = None
        return self.finish(losses, removed)
