"""Source-only DINO research candidates, not empirically validated improvements.

CF: box-protected context counterfactuals + positive DN query consistency.
MP: multi-mode, source-domain encoder prototypes + residual query retrieval.
RB: bounded source-risk weighting + matched-query foreground/background ranking.
No target labels/statistics are read during prediction. Python >= 3.8.
"""
import math
from pathlib import PurePosixPath
import torch
from torch import nn
from torch.nn import functional as F
from mmengine.structures import InstanceData
from mmdet.registry import MODELS
from mmdet.structures.bbox import bbox_cxcywh_to_xyxy, bbox_overlaps
from mmdet.models.detectors.dino import DINO

DOMAINS = ('stomach_instance', 'organoid_basic', 'human_lung', 'mouse_intestine')


def domain_id(sample):
    meta = sample.metainfo
    value = meta.get('domain_name', '')
    if value in DOMAINS:
        return DOMAINS.index(value)
    parts = PurePosixPath(str(meta.get('img_path', '')).replace('\\', '/')).parts
    found = [i for i, name in enumerate(DOMAINS) if name in parts]
    if len(found) != 1:
        raise ValueError('Cannot audit source domain from img_path: %r' % meta.get('img_path'))
    return found[0]


def boxes(sample):
    value = sample.gt_instances.bboxes
    return value.tensor if hasattr(value, 'tensor') else value


def check_samples(samples):
    """Filter degenerate post-augmentation boxes on copies; never alter original annotations."""
    result, removed = [], 0
    for sample in samples:
        copied = sample.clone()
        b = boxes(copied)
        if not torch.isfinite(b).all():
            raise FloatingPointError('Non-finite source GT boxes')
        valid = (b[:, 2] > b[:, 0]) & (b[:, 3] > b[:, 1])
        removed += int((~valid).sum().item())
        copied.gt_instances = copied.gt_instances[valid]
        domain_id(copied)
        result.append(copied)
    return result, removed


def masks_for(feature, sample):
    """Coarse BOX support, not segmentation. Exclude padding from all statistics."""
    h, w = feature.shape[-2:]
    ph, pw = sample.metainfo['batch_input_shape'][:2]
    ih, iw = sample.metainfo['img_shape'][:2]
    ys = (torch.arange(h, device=feature.device) + .5) * (ph / h)
    xs = (torch.arange(w, device=feature.device) + .5) * (pw / w)
    valid = (ys[:, None] < ih) & (xs[None, :] < iw)
    foreground = torch.zeros((h, w), device=feature.device, dtype=torch.bool)
    for box in boxes(sample).detach():
        # 10% margin conservatively protects object boundaries.
        dx, dy = (box[2] - box[0]) * .1, (box[3] - box[1]) * .1
        foreground |= ((xs[None, :] >= box[0] - dx) & (xs[None, :] <= box[2] + dx)
                       & (ys[:, None] >= box[1] - dy) & (ys[:, None] <= box[3] + dy))
    return foreground & valid, (~foreground) & valid


def roi_vectors(feature, sample, limit=48):
    b = boxes(sample)
    if not len(b):
        return feature.new_zeros((0, feature.shape[0]))
    # Deterministic spread: not biased towards the first/last annotations.
    ids = torch.linspace(0, len(b)-1, min(limit, len(b)), device=b.device).long()
    b = b[ids].float()
    ph, pw = sample.metainfo['batch_input_shape'][:2]
    axis = torch.tensor([.25, .5, .75], device=b.device)
    y, x = torch.meshgrid(axis, axis, indexing='ij')
    gx = b[:, 0, None] + (b[:, 2] - b[:, 0])[:, None] * x.flatten()[None]
    gy = b[:, 1, None] + (b[:, 3] - b[:, 1])[:, None] * y.flatten()[None]
    grid = torch.stack([gx / pw * 2 - 1, gy / ph * 2 - 1], -1)[None]
    return F.grid_sample(feature[None].float(), grid, align_corners=False).squeeze(0).mean(-1).t()


def scalar(value):
    if isinstance(value, (list, tuple)):
        return sum(x.mean() for x in value)
    return value.mean()


def total_loss(losses):
    return sum(scalar(value) for key, value in losses.items() if 'loss' in key)


class SourceDINO(DINO):
    def __init__(self, *args, candidate_cfg=None, **kwargs):
        self.candidate_cfg = dict(candidate_cfg or {})
        super().__init__(*args, **kwargs)
        self.register_buffer('candidate_step', torch.zeros((), dtype=torch.long))
        self.smoke_mode = False

    def ramp(self):
        if self.smoke_mode:
            return 1.0
        return min(1.0, float(self.candidate_step.item()) / max(1, self.candidate_cfg.get('warmup_steps', 500)))

    def finish(self, losses, removed):
        for key, value in losses.items():
            if not torch.isfinite(scalar(value)).all():
                raise FloatingPointError('Non-finite %s at step %d' % (key, self.candidate_step.item()))
        losses['gt_filtered'] = self.candidate_step.new_tensor(float(removed), dtype=torch.float)
        self.candidate_step.add_(1)
        return losses


@MODELS.register_module(name='Combo24ContextCF')
class DINOContextCF(SourceDINO):
    """One backbone, occasional second transformer pass, no inference branch."""
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        shape = (4, self.num_feature_levels, self.embed_dims)
        self.register_buffer('context_mean', torch.zeros(shape))
        self.register_buffer('context_std', torch.ones(shape))
        self.register_buffer('context_seen', torch.zeros(4, self.num_feature_levels, dtype=torch.bool))

    def counterfactual(self, features, samples):
        changed, used = [], 0
        strength = float(self.candidate_cfg.get('strength', .3)) * self.ramp()
        for level, x in enumerate(features):
            out = []
            for i, sample in enumerate(samples):
                d = domain_id(sample)
                _, bg = masks_for(x[i], sample)
                if int(bg.sum()) < 4:
                    out.append(x[i]); continue
                # Detached style statistics prevent a trivial gradient through donor moments.
                pixels = x[i].detach().float()[:, bg]
                mean = pixels.mean(1)
                std = pixels.var(1, unbiased=False).add(1e-4).sqrt()
                with torch.no_grad():
                    if self.context_seen[d, level]:
                        self.context_mean[d, level].lerp_(mean, .05)
                        self.context_std[d, level].lerp_(std, .05)
                    else:
                        self.context_mean[d, level].copy_(mean)
                        self.context_std[d, level].copy_(std)
                        self.context_seen[d, level] = True
                donors = [j for j in range(4) if j != d and bool(self.context_seen[j, level])]
                if not donors:
                    out.append(x[i]); continue
                donor = donors[int(torch.randint(len(donors), ()).item())]
                dm = self.context_mean[donor, level].detach().clone()
                ds = self.context_std[donor, level].detach().clone()
                ratio = (ds / std.clamp_min(.01)).clamp(.7, 1.4)
                delta = (x[i].float() - mean[:, None, None]) * (ratio[:, None, None] - 1)
                delta = delta + (dm - mean).clamp(-std, std)[:, None, None]
                out.append((x[i].float() + strength * bg[None] * delta).to(x.dtype))
                used += 1
            changed.append(torch.stack(out))
        return tuple(changed), used

    def loss(self, batch_inputs, batch_data_samples):
        samples, removed = check_samples(batch_data_samples)
        features = self.extract_feat(batch_inputs)
        # Snapshot RNG so the two DN branches refer to identical perturbed GT queries.
        cpu_rng = torch.get_rng_state()
        device = batch_inputs.device
        cuda_rng = torch.cuda.get_rng_state(device) if device.type == 'cuda' else None
        heads = self.forward_transformer(features, samples)
        losses = self.bbox_head.loss(**heads, batch_data_samples=samples)
        zero = heads['hidden_states'].sum() * 0
        losses.update(loss_context_cf=zero, loss_dn_invariance=zero, cf_active=zero.detach())
        altered, used = self.counterfactual(features, samples)
        probability = self.candidate_cfg.get('cf_probability', .25)
        if used and (self.smoke_mode or float(torch.rand(())) < probability):
            devices = [device.index if device.index is not None else torch.cuda.current_device()] if device.type == 'cuda' else []
            with torch.random.fork_rng(devices=devices):
                torch.set_rng_state(cpu_rng)
                if cuda_rng is not None:
                    torch.cuda.set_rng_state(cuda_rng, device)
                other = self.forward_transformer(altered, samples)
            cf_losses = self.bbox_head.loss(**other, batch_data_samples=samples)
            losses['loss_context_cf'] = self.ramp() * self.candidate_cfg.get('cf_weight', .25) * total_loss(cf_losses)
            meta = heads.get('dn_meta') or {}
            n, groups = int(meta.get('num_denoising_queries', 0)), int(meta.get('num_denoising_groups', 0))
            terms = []
            if n and groups:
                group_size = n // groups
                for i, sample in enumerate(samples):
                    count = len(boxes(sample))
                    if count:
                        ids = (torch.arange(groups, device=device)[:, None] * group_size
                               + torch.arange(count, device=device)[None]).flatten()
                        teacher = F.normalize(heads['hidden_states'][-1, i, ids].detach().float(), dim=-1)
                        student = F.normalize(other['hidden_states'][-1, i, ids].float(), dim=-1)
                        terms.append((1 - (teacher * student).sum(-1)).mean())
            if terms:
                losses['loss_dn_invariance'] = self.candidate_cfg.get('consistency_weight', .1) * self.ramp() * torch.stack(terms).mean()
            losses['cf_active'] = zero.detach() + 1
        return self.finish(losses, removed)


@MODELS.register_module(name='Combo24MorphPrototype')
class DINOMorphPrototype(SourceDINO):
    """Source-only multi-mode foreground codebook in ENCODER space, shared by query retrieval."""
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.modes = int(self.candidate_cfg.get('modes', 4))
        self.register_buffer('morph_bank', torch.zeros(4, self.modes, self.embed_dims))
        self.register_buffer('morph_seen', torch.zeros(4, self.modes, dtype=torch.bool))
        self.prototype_projection = nn.Linear(self.embed_dims, self.embed_dims)
        nn.init.zeros_(self.prototype_projection.weight)
        nn.init.zeros_(self.prototype_projection.bias)
        self._prototype_aux = None

    @torch.no_grad()
    def update_bank(self, d, vectors):
        for vec in F.normalize(vectors.detach().float(), dim=-1):
            seen = self.morph_seen[d]
            if not seen.all():
                j = int((~seen).nonzero()[0])
                self.morph_bank[d, j].copy_(vec)
                self.morph_seen[d, j] = True
            else:
                j = int((self.morph_bank[d] @ vec).argmax())
                self.morph_bank[d, j].copy_(F.normalize(.95 * self.morph_bank[d, j] + .05 * vec, dim=0))

    def pre_decoder(self, memory, memory_mask, spatial_shapes, batch_data_samples=None):
        dec, head = super().pre_decoder(memory, memory_mask, spatial_shapes, batch_data_samples)
        # Reconstruct only the first encoder level for bounded ROI sampling.
        h, w = [int(v) for v in spatial_shapes[0]]
        dense = memory[:, :h*w].transpose(1, 2).reshape(memory.shape[0], memory.shape[-1], h, w)
        aux = memory.sum() * 0
        if self.training:
            records = []
            for i, sample in enumerate(batch_data_samples):
                d = domain_id(sample)
                roi = roi_vectors(dense[i], sample)
                _, bgmask = masks_for(dense[i], sample)
                bg = dense[i, :, bgmask].mean(1) if bgmask.any() else None
                records.append((d, roi, bg))
            # Snapshot before updates so gradients never alias mutable buffers.
            bank, seen = self.morph_bank.detach().clone(), self.morph_seen.clone()
            terms = []
            for d, roi, bg in records:
                if len(roi) and bg is not None:
                    normalized = F.normalize(roi.float(), dim=-1)
                    others = seen.clone(); others[d] = False
                    if others.any():
                        similarity = normalized @ bank[others].t()
                        best = similarity.max(-1).values
                        reliability = ((best.detach() - .4) / .4).clamp(0, 1)
                        # Pull only reliable cross-source mode matches, not all same-class instances.
                        terms.append((reliability * (1 - best)).mean())
                    # Foreground/background separation without collapsing all morphology modes.
                    negative = F.normalize(bg.float(), dim=0)
                    terms.append(F.relu((normalized * negative).sum(-1) - .3).mean())
                if len(roi):
                    self.update_bank(d, roi)
            if terms:
                aux = torch.stack(terms).mean()
        self._prototype_aux = aux
        known = self.morph_seen.flatten()
        if known.any():
            bank = self.morph_bank.flatten(0, 1)[known].detach().clone()
            refs = dec['reference_points'][:, -self.num_queries:, :2]
            # Reference coordinates are relative to valid image extent; map to padded feature grid.
            ratios = []
            for sample in batch_data_samples:
                ih, iw = sample.metainfo['img_shape'][:2]
                ph, pw = sample.metainfo['batch_input_shape'][:2]
                ratios.append([iw/pw, ih/ph])
            ratios = refs.new_tensor(ratios)[:, None]
            grid = (refs * ratios * 2 - 1).unsqueeze(2)
            descriptors = F.grid_sample(dense.float(), grid.float(), align_corners=False).squeeze(-1).transpose(1, 2)
            similarity = F.normalize(descriptors, dim=-1) @ bank.t()
            weights = (similarity / .2).softmax(-1)
            reliability = ((similarity.max(-1).values.detach() - .3) / .5).clamp(0, 1)
            residual = self.prototype_projection(weights @ bank)
            q = dec['query']
            amplitude = self.candidate_cfg.get('query_strength', .1)
            if self.training:
                amplitude *= self.ramp()
            # Bounded residual cannot overwhelm a pretrained query in a single step.
            matching = q[:, -self.num_queries:] + amplitude * reliability[..., None] * residual.tanh()
            dec['query'] = torch.cat([q[:, :-self.num_queries], matching], dim=1)
        return dec, head

    def loss(self, batch_inputs, batch_data_samples):
        samples, removed = check_samples(batch_data_samples)
        heads = self.forward_transformer(self.extract_feat(batch_inputs), samples)
        losses = self.bbox_head.loss(**heads, batch_data_samples=samples)
        losses['loss_morph_prototype'] = self.candidate_cfg.get('prototype_weight', .1) * self.ramp() * self._prototype_aux
        losses['prototype_count'] = self.morph_seen.float().sum().detach()
        self._prototype_aux = None
        return self.finish(losses, removed)


@MODELS.register_module(name='Combo24RiskBalanced')
class DINORiskBalanced(SourceDINO):
    """Bounded domain risk control with matched positive vs hard-background query ranking."""
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.register_buffer('domain_risk', torch.ones(4))
        self.register_buffer('risk_seen', torch.zeros(4, dtype=torch.bool))

    def ranking(self, logits, predictions, samples):
        terms = []
        for i, sample in enumerate(samples):
            gt = sample.gt_instances
            b = boxes(sample)
            if not len(b):
                continue
            ih, iw = sample.metainfo['img_shape'][:2]
            absolute = bbox_cxcywh_to_xyxy(predictions[i].detach()) * predictions.new_tensor([iw, ih, iw, ih])
            assigned = self.bbox_head.assigner.assign(
                pred_instances=InstanceData(scores=logits[i].detach(), bboxes=absolute),
                gt_instances=gt, img_meta=sample.metainfo)
            ious = bbox_overlaps(absolute, b).max(-1).values
            positive = (assigned.gt_inds > 0) & (ious >= .5)
            negative = (assigned.gt_inds == 0) & (ious < .2)
            if positive.any() and negative.any():
                scores = logits[i].float().max(-1).values
                hard = scores[negative].topk(min(32, int(negative.sum()))).values
                # Margin ranking on probabilities, bounded and independent of absolute logit scale.
                terms.append(F.relu(.1 + hard.sigmoid()[None] - scores[positive].sigmoid()[:, None]).mean())
        return torch.stack(terms).mean() if terms else logits.sum() * 0

    def loss(self, batch_inputs, batch_data_samples):
        samples, removed = check_samples(batch_data_samples)
        heads = self.forward_transformer(self.extract_feat(batch_inputs), samples)
        all_scores, all_boxes = self.bbox_head(heads['hidden_states'], heads['references'])
        per_image = []
        for i, sample in enumerate(samples):
            per_image.append(self.bbox_head.loss_by_feat(
                all_scores[:, i:i+1], all_boxes[:, i:i+1],
                heads['enc_outputs_class'][i:i+1], heads['enc_outputs_coord'][i:i+1],
                [sample.gt_instances], [sample.metainfo], heads['dn_meta']))
        # Each image has equal weight before source-risk weighting; this differs from
        # the stock globally object-normalized batch reduction and is disclosed.
        risks = torch.stack([total_loss(x).detach().float() for x in per_image])
        if not torch.isfinite(risks).all():
            raise FloatingPointError('Non-finite per-image detection risk')
        ids = [domain_id(sample) for sample in samples]
        with torch.no_grad():
            for d in set(ids):
                value = risks[[i for i, k in enumerate(ids) if k == d]].mean()
                if self.risk_seen[d]:
                    self.domain_risk[d].lerp_(value, .05)
                else:
                    self.domain_risk[d].copy_(value)
                    self.risk_seen[d] = True
        weights = torch.ones_like(self.domain_risk)
        seen = self.risk_seen
        risk = self.domain_risk[seen].detach()
        relative = (risk / risk.mean().clamp_min(1e-5) - 1).clamp(-1, 1)
        weights[seen] = (relative * .5).exp().clamp(.75, 1.5)
        weights[seen] /= weights[seen].mean()
        selected = 1 + self.ramp() * (weights[ids].detach() - 1)
        losses = {key: sum(selected[i] * scalar(row[key]) for i, row in enumerate(per_image)) / len(samples)
                  for key in per_image[0]}
        dn = int((heads.get('dn_meta') or {}).get('num_denoising_queries', 0))
        losses['loss_query_rank'] = self.candidate_cfg.get('ranking_weight', .2) * self.ramp() * self.ranking(
            all_scores[-1, :, dn:], all_boxes[-1, :, dn:], samples)
        losses['source_weight_mean'] = selected.mean().detach()
        losses['source_weight_max'] = selected.max().detach()
        return self.finish(losses, removed)
